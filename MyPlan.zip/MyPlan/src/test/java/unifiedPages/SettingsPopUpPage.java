package unifiedPages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import webdrivermethods.ProjectMethods;

public class SettingsPopUpPage extends ProjectMethods {
	public SettingsPopUpPage() {
		PageFactory.initElements(driver, this);
	}

	// Add sunday
	@FindBy(xpath = "//button[text()='Su']")
	WebElement AddSunday;

	public SettingsPopUpPage AddSunday() {
		click(AddSunday);

		return this;
	}

	// Add Monday
	@FindBy(xpath = "//button[text()='Mo']")
	WebElement AddMonday;

	public SettingsPopUpPage AddMonday() {
		click(AddMonday);

		return this;
	}

	// Add Tuesday
	@FindBy(xpath = "//button[text()='Tu']")
	WebElement AddTuesday;

	public SettingsPopUpPage AddTuesday() {
		click(AddTuesday);

		return this;
	}

	// Add Wednesday
	@FindBy(xpath = "//button[text()='We']")
	WebElement AddWednesday;

	public SettingsPopUpPage AddWednesday() {
		click(AddWednesday);

		return this;
	}

	// Add Thursday
	@FindBy(xpath = "//button[text()='Th']")
	WebElement AddThursday;

	public SettingsPopUpPage AddThursday() {
		click(AddThursday);

		return this;
	}

	// Add Friday

	@FindBy(xpath = "//button[text()='Fr']")
	WebElement AddFriday;

	public SettingsPopUpPage AddFriday() {
		click(AddFriday);

		return this;
	}

	// Add saturday day extra
	@FindBy(xpath = "//button[text()='Sa']")
	WebElement Addsaturday;

	public SettingsPopUpPage Addsaturday() {
		click(Addsaturday);

		return this;
	}

	// Click End button

	@FindBy(xpath = "//div[text()='End']")
	WebElement ClickProgramEndButton;

	public SettingsPopUpPage ClickProgramEndButton() {
		click(ClickProgramEndButton);

		return this;
	}

	// Click End Program Confirmation
	@FindBy(xpath = "//div[text()='End program']")
	WebElement EndProgramConfirmation;

	public MyPlanPage EndProgramConfirmation() {
		click(EndProgramConfirmation);

		return new MyPlanPage();
	}

	// Click pause button

	@FindBy(xpath = "//div[text()='Pause']")
	WebElement ClickProgramPauseButton;

	public SettingsPopUpPage ClickProgramPauseButton() {
		click(ClickProgramPauseButton);

		return this;
	}

	// Click Pause Program Confirmation
	@FindBy(xpath = "//div[text()='Pause program']")
	WebElement PauseProgramConfirmation;

	public MyPlanPage PauseProgramConfirmation() {
		click(PauseProgramConfirmation);

		return new MyPlanPage();
	}

	// Click Resume Program option
	@FindBy(xpath = "//div[text()='Resume program']")
	WebElement ClickResumeOption;

	public SettingsPopUpPage ClickResumeOption() {
		click(ClickResumeOption);

		return this;
	}

	// Click Save
	@FindBy(xpath = "//div[text()='Save']")
	WebElement Clicksaveindays;

	public MyPlanPage Clicksaveindays() {
		click(Clicksaveindays);

		return new MyPlanPage();
	}

	// Notification message while select all the dates
	@FindBy(xpath = "//div[text()='Please select between 1 and 6 workouts per week.']")
	WebElement Notificationforalldays;

	public SettingsPopUpPage Notificationforalldays() {
		String copy = driver.findElementByXPath("//div[text()='Please select between 1 and 6 workouts per week.']")
				.getText();
		Assert.assertEquals(copy, "Please select between 1 and 6 workouts per week.");

		return this;

	}

}
