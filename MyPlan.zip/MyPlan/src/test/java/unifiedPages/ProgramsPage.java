package unifiedPages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import webdrivermethods.ProjectMethods;

public class ProgramsPage extends ProjectMethods {

	public ProgramsPage() {
		PageFactory.initElements(driver, this);
	}

	// Click Start Program
	@FindBy(xpath = "//div[text()='Start program']")
	WebElement ClickStartProgram;

	public SettingsPopUpPage ClickStartProgram() {
		click(ClickStartProgram);
		return new SettingsPopUpPage();

	}

	// Click Preview option
	@FindBy(xpath = "//div[text()='Preview']")
	WebElement ClickPreviewOption;

	public PreviewOptionsPage ClickPreviewOption() {
		click(ClickPreviewOption);
		return new PreviewOptionsPage();
	}

}
