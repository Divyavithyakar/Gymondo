package unifiedPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import webdrivermethods.ProjectMethods;

public class LoginPage extends ProjectMethods {

	public LoginPage() {
		PageFactory.initElements(driver, this);
	}

	// Click login
	@FindBy(xpath = "//div[text()='Log in']")
	WebElement ClickLoginOption;

	public LoginPage ClickLoginOption() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Log in']")));
		click(ClickLoginOption);

		return this;
	}

	// Enter Username
	@FindBy(id = "mail")
	WebElement EnterUserName;

	public LoginPage EnterUserName(String data) {
		type(EnterUserName, data);
		return this;
	}

	// Enter Password
	@FindBy(id = "password")
	WebElement EnterPassword;

	public LoginPage EnterPaswword(String data1) {
		type(EnterPassword, data1);
		return this;
	}

	// Click Login
	@FindBy(xpath = "//button[@type='submit']")
	WebElement ClickLogin;

	public MyPlanPage ClickLogin() {
		click(ClickLogin);

		return new MyPlanPage();
	}

}
