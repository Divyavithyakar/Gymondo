package unifiedPages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import webdrivermethods.ProjectMethods;

public class MyPlanPage extends ProjectMethods {

	public MyPlanPage() {
		PageFactory.initElements(driver, this);
	}

	// Verify the Start program element
	@FindBy(xpath = "//button[@type='button']//div")
	WebElement VerifyNewStartProgramText;

	public MyPlanPage VerifyNewStartProgramText() {

		if (driver.findElementByXPath("//button[@type='button']//div") != null) {
			System.out.println("Element is present");
		} else {
			System.out.println("Element is Absent");

		}
		return this;
	}

	// Click Start new Program
	@FindBy(xpath = "//button[@type='button']//div")
	WebElement ClickStartNewProgram;

	public ProgramsPage ClickStartNewProgram() {

		click(ClickStartNewProgram);
		return new ProgramsPage();
	}

	// Click got it button for new user
	@FindBy(xpath = "//div[text()='Got it']")
	WebElement ClickGotit;

	public MyPlanPage ClickGotit() {
		click(ClickGotit);

		return this;

	}

	// Click Scrolldown
	@FindBy(xpath = "//html[@lang='en']")
	WebElement ClickScrolldown;

	public MyPlanPage ClickScrolldown() {
		Actions dummy = new Actions(driver);
		dummy.sendKeys(Keys.ARROW_DOWN, Keys.RETURN).build().perform();
		Actions dummy1 = new Actions(driver);
		dummy1.sendKeys(Keys.ARROW_DOWN, Keys.RETURN).build().perform();
		Actions dummy2 = new Actions(driver);
		dummy2.sendKeys(Keys.ARROW_DOWN, Keys.RETURN).build().perform();
		Actions dummy3 = new Actions(driver);
		dummy3.sendKeys(Keys.ARROW_DOWN, Keys.RETURN).build().perform();
		Actions dummy4 = new Actions(driver);
		dummy4.sendKeys(Keys.ARROW_DOWN, Keys.RETURN).build().perform();
		Actions dummy5 = new Actions(driver);
		dummy5.sendKeys(Keys.ARROW_DOWN, Keys.RETURN).build().perform();

		return this;

	}

	// Click Plan Settings
	@FindBy(xpath = "(//button[@type='button']//div)[2]")
	WebElement ClickPlanSettings;

	public SettingsPopUpPage ClickPlanSettings() {
		click(ClickPlanSettings);

		return new SettingsPopUpPage();
	}

}