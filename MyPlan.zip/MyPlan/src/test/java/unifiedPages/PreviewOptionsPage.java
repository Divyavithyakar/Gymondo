package unifiedPages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import webdrivermethods.ProjectMethods;

public class PreviewOptionsPage extends ProjectMethods {
	public PreviewOptionsPage() {
		PageFactory.initElements(driver, this);
	}

	// Click pause button
	@FindBy(xpath = "//div[contains(@class,'modal_backdrop__yFtnK fade-appear-done')]/following-sibling::div[1]")
	WebElement PauseButton;

	public PreviewOptionsPage PauseButton() {
		click(PauseButton);

		return this;
	}

	// Mute option
	@FindBy(xpath = "(//button[@type='button']//div)[2]")
	WebElement MuteOption;

	public PreviewOptionsPage MuteOption() {
		click(MuteOption);

		return this;
	}

	// Maximize
	@FindBy(xpath = "(//button[@type='button']//div)[2]")
	WebElement Maximize;

	public PreviewOptionsPage Maximize() {
		click(Maximize);

		return this;
	}

}
