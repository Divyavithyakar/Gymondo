package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import unifiedPages.LoginPage;
import webdrivermethods.ProjectMethods;

public class TC001StartNewProgram extends ProjectMethods{

	@BeforeTest
	public void setData() {
		testCaseName = "Start New Program Flow";
		testDescription = "My Plan";
		testNodes = "New Program";
		authors = "Divya";
		category = "smoke";
		dataSheetName = "TC001";
	}

	@Test(dataProvider="fetchData")
	public void tC001StartNewProgram(String data,String data1) throws InterruptedException {
		new LoginPage()
		.ClickLoginOption()
		.EnterUserName(data)
		.EnterPaswword(data1)
		.ClickLogin()
		.ClickGotit()
		.ClickScrolldown()
		.VerifyNewStartProgramText()
		.ClickStartNewProgram()
		.ClickStartProgram();
		}


}
