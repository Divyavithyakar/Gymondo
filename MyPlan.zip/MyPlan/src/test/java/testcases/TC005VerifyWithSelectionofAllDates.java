package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import unifiedPages.LoginPage;
import webdrivermethods.ProjectMethods;

public class TC005VerifyWithSelectionofAllDates extends ProjectMethods{
	
	@BeforeTest
	public void setData() {
		testCaseName = "Max and Min days flow with validation";
		testDescription = "My Plan";
		testNodes = "Days Selection";
		authors = "Divya";
		category = "smoke";
		dataSheetName = "TC001";
	}

	@Test(dataProvider="fetchData")
	public void tC005VerifyWithSelectionofAllDates(String data,String data1) throws InterruptedException {
		new LoginPage()
		.ClickLoginOption()
		.EnterUserName(data)
		.EnterPaswword(data1)
		.ClickLogin()
		.ClickGotit()
		.ClickPlanSettings()
		.AddSunday()
		.Notificationforalldays()
		.AddMonday()
		.AddTuesday()
		.AddWednesday()
		.AddThursday()
		.AddFriday()
		.Addsaturday()
		.Notificationforalldays()
		.Clicksaveindays();
		
	}

}
