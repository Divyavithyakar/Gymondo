package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import unifiedPages.LoginPage;
import webdrivermethods.ProjectMethods;

public class TC006PreviewOption extends ProjectMethods{
	
	@BeforeTest
	public void setData() {
		testCaseName = "Preview Option";
		testDescription = "My Plan";
		testNodes = "Preview";
		authors = "Divya";
		category = "smoke";
		dataSheetName = "TC001";
	}

	@Test(dataProvider="fetchData")
	public void tC006PreviewOption(String data,String data1) throws InterruptedException {
		new LoginPage()
		.ClickLoginOption()
		.EnterUserName(data)
		.EnterPaswword(data1)
		.ClickLogin()
		.ClickGotit()
		.ClickPlanSettings()
		.ClickProgramEndButton()
		.EndProgramConfirmation()
		.ClickScrolldown()
		.VerifyNewStartProgramText()
		.ClickStartNewProgram()
		.ClickPreviewOption()
		.PauseButton();
	}
}
