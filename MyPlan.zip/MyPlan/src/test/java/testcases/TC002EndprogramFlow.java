package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import unifiedPages.LoginPage;
import webdrivermethods.ProjectMethods;

public class TC002EndprogramFlow extends ProjectMethods{
	@BeforeTest
	public void setData() {
		testCaseName = "End Program Flow";
		testDescription = "My Plan";
		testNodes = "End Program";
		authors = "Divya";
		category = "smoke";
		dataSheetName = "TC001";
	}

	@Test(dataProvider="fetchData")
	public void tC002EndprogramFlow(String data,String data1) throws InterruptedException {
		new LoginPage()
		.ClickLoginOption()
		.EnterUserName(data)
		.EnterPaswword(data1)
		.ClickLogin()
		.ClickGotit()
		.ClickPlanSettings()
		.ClickProgramEndButton()
		.EndProgramConfirmation()
		.ClickScrolldown()
		.VerifyNewStartProgramText()
		.ClickStartNewProgram();
		
		}

}
